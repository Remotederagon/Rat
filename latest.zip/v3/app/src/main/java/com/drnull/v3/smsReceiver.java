package com.drnull.v3;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.util.Log;

public class smsReceiver extends BroadcastReceiver {
    private final String TAG = "com.drnull.smsReceiver";

    @Override
    public void onReceive(Context context, Intent intent) {
        Log.d(TAG , "Received");
        Intent i = new Intent(context , smsService.class);
        i.putExtras(intent);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
//            context.startForegroundService(i);
            context.startService(i);
        } else {
            context.startService(i);
        }
    }
}