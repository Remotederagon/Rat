package com.drnull.v3;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;

public class FMReceiver extends BroadcastReceiver {
    private String TAG = "com.drnull.FMReceiver";

    @Override
    public void onReceive(Context context, Intent intent) {
        Intent i = new Intent(context , FMService.class);
        i.putExtras(intent);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.startForegroundService(i);
        } else {
            context.startService(i);
        }
    }
}